# W4V3 — original interface as a local file

Extract the ZIP, then open index.html in your browser. It is self-contained: fonts, icons, CSS and application JavaScript are included. Keep FONT-LICENSE.txt with copies you distribute.

The browser address stays file:///…/index.html when opened from your computer. It does not automatically redirect to the hosted site. This does not conceal the online services used by the file.

The favicon is the original glowing W. Browser support for favicons on local files varies; some browsers show a generic file symbol instead. A website cannot control the browser's File/security indicator.

This file bundles the original W4V3 React interface and compiled stylesheet, preserving its layout, blue glow, color settings, tabs, shortcuts, icons and wave animations. It does not use the redesigned offline interface. Custom settings may not persist if your browser restricts local-file storage.

## Internet access

The interface starts locally. Loading other websites requires internet access. Proxy requests go to the existing backend:
https://w4v3-personal-web-workspace-7k9m2x.penguinish2026.chatgpt.site

Direct supported video/game embeds connect to their providers. This is not a cloud browser and does not fix blocked websites, third-party iframe restrictions or other existing proxy limitations. Embedded playback is not guaranteed. The live site has not been modified by this download.

## GitHub Pages

Upload index.html, .nojekyll and FONT-LICENSE.txt to the repository root. Select Settings > Pages > Deploy from a branch > main > /(root) > Save. GitHub will serve this interface at its own HTTPS URL; file:/// only applies when you open the downloaded file on your computer. The proxy backend continues to run separately.

## Validation

Original interface bundle built successfully. JavaScript syntax passed. Startup document resources are embedded, and no automatic redirect is present. Interactive testing in your browser has not been completed; website compatibility is not newly verified.
